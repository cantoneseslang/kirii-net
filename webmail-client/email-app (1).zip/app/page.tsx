import { GmailApp } from "../email-app"

export default function Page() {
  return <GmailApp />
}
